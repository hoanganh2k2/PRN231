﻿namespace EFCore_Api.Dto
{
    public class PagedResponse<T>
    {
    }
}
