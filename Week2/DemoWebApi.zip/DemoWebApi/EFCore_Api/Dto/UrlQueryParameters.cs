﻿namespace EFCore_Api.Dto
{
    public class UrlQueryParameters
    {
    }
}
