﻿namespace EFCore_Api.Dto.PlayerInstrument
{
    public class GetPlayerInstrumentResponse
    {
    }
}
