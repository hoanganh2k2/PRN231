﻿namespace EFCore_Api.Dto.PlayerInstrument
{
    public class CreatePlayerInstrumentRequest
    {
    }
}
