﻿namespace EFCore_Api.Db.Model
{
    public class InstrumentType
    {
        public int InstrumentTypeId { get; set; }
        public string Name { get; set; }
    }
}
