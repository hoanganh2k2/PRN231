﻿namespace DemoWebAPI_Video.Log
{
    public interface ILogging
    {
        public void Log(string message, string type);
    }
}
