﻿using DemoWebAPI_Video.Models;
using Microsoft.EntityFrameworkCore;

namespace DemoWebAPI_Video.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public DbSet<Villa> Villas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Villa>().HasData(
                new Villa()
                {
                    Id = 1,
                    Name = "Royal Villa",
                    Details = "Good",
                    ImageUrl = "https://www.cet.edu.vn/wp-content/uploads/2019/02/villa-khong-gian-sang-trong.jpg",
                    Occupancy = 5,
                    Sqft = 500,
                    Rate = 200,
                    Amenity = "",
                    CreatedDate = DateTime.Now
                },
                new Villa()
                {
                    Id = 2,
                    Name = "VIP Villa",
                    Details = "Good",
                    ImageUrl = "https://s-real.vn/wp-content/uploads/2021/09/Villa-l%C3%A0-g%C3%AC-2048x1280.jpg",
                    Occupancy = 6,
                    Sqft = 600,
                    Rate = 300,
                    Amenity = "",
                    CreatedDate = DateTime.Now
                },
                new Villa()
                {
                    Id = 3,
                    Name = "Muong Thanh Villa",
                    Details = "Good",
                    ImageUrl = "https://img.vistarooms.com/gallery/vista-sadh-villa-c227d4.jpg",
                    Occupancy = 4,
                    Sqft = 300,
                    Rate = 150,
                    Amenity = "",
                    CreatedDate = DateTime.Now
                });
        }
    }
}
